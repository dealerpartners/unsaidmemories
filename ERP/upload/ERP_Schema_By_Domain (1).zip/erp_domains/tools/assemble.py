#!/usr/bin/env python3
"""Rebuild one executable SQL file from a domain tree, in original dependency order.
Usage: assemble.py DOMAIN_TREE_DIR OUTPUT.sql [--only 11,13,...]   (--only is for reading, not deploying)"""
import os, re, sys
root, out = sys.argv[1], sys.argv[2]
only = set(sys.argv[sys.argv.index('--only')+1].split(',')) if '--only' in sys.argv else None
items=[]
for d in sorted(os.listdir(root)):
    p=os.path.join(root,d)
    if not os.path.isdir(p) or (only and d[:2] not in only): continue
    for f in sorted(os.listdir(p)):
        if not f.endswith('.sql'): continue
        txt=open(os.path.join(p,f),encoding='utf-8').read()
        for m in re.finditer(r'^-- @seq (\d+)\n(.*?)(?=^-- @seq \d+\n|\Z)', txt, re.S|re.M):
            items.append((int(m.group(1)), m.group(2).strip()))
items.sort()
seqs=[s for s,_ in items]
assert len(seqs)==len(set(seqs)), 'duplicate @seq tags'
with open(out,'w') as fh:
    fh.write('SET check_function_bodies = false;\n\n')
    for s,b in items: fh.write(b+'\n\n')
print(f'{len(items)} statements -> {out}')
