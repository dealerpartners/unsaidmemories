import csv, json, collections, re
from domains import classify, NAMES
W='/home/user/workspace/erp_domains/'
def load(d):
    s=set()
    for line in open(W+f'catalog_{d}.tsv'):
        k,sc,n,x=(line.rstrip('\n').split('\t')+['',''])[:4]
        s.add((k,sc,n,x))
    return s
prod,sept,full=load('prod'),load('sept'),load('full')
inv=json.load(open(W+'inventory.json'))
deffiles=collections.defaultdict(set)
for r in inv:
    for f in r['files']: deffiles[(r['kind'],r['name'])].add(f)
ext_fns={'gtrgm','gin_','similarity','word_similarity','strict_word','set_limit','show_limit','show_trgm'}
# duplicate clusters -> canonical
DUP={
 'employees':('acct_employees',['acct_payroll_employees','payroll_employees','crm_staff','staff']),
 'payroll_runs':('acct_payroll_runs',['payroll_runs','payroll_run_items']),
 'payroll_tax_forms':('acct_payroll_tax_forms',['payroll_tax_forms']),
 'time':('acct_time_entries',['acct_timesheets','payroll_timesheets','crm_staff_time_clock_entries','support_time_entries']),
 'inventory_qty':('erp_inventory_movements',['inventory_items','inventory_levels','inventory_transactions','commerce_inventory_events','erp_inventory_transactions','erp_stock_levels']),
 'inventory_cost':('erp_inventory_cost_layers',['acct_inventory_layers','acct_inventory_layer_draws','acct_inventory_moves']),
 'gift_cards':('commerce_gift_cards',['acct_gift_cards','acct_gift_card_transactions']),
 'refunds':('commerce_refunds',['acct_refunds','erp_return_refunds']),
 'disputes':('commerce_disputes',['acct_disputes']),
 'statements':('acct_customer_statements',['customer_statements']),
 'subscriptions':('commerce_subscriptions',['subscriptions','subscription_plans']),
 'audit':('platform_audit_events (new)',['acct_audit_log','cms_audit_log','commerce_audit_log','crm_audit_log','erp_audit_log','activity_log']),
 'idempotency':('platform_idempotency_keys (new)',['acct_integration_idempotency','commerce_idempotency','crm_idempotency_keys','erp_idempotency_keys']),
 'outbox':('platform_outbox (new)',['commerce_outbox_events','social_outbox_events','email_outbox']),
 'webhook_inbox':('integration_webhook_inbox',['stripe_webhook_events','paypal_webhook_events','commerce_webhook_events']),
 'rev_schedules':('acct_revenue_recognition_schedules',['acct_recognition_schedules','acct_recognition_lines']),
 'calc_runs':('calc.runs (new)',['tax16.calculation_runs','calc17.runs','partnership18.runs','taxprod.runs']),
 'jobs':('platform_jobs (new)',['sync_jobs','support_jobs','provider_jobs','tax16.jobs']),
 'customers':('crm_customers',['customers','acct_customers','commerce_customer_accounts','order_customers']),
 'vendors':('acct_vendors',['vendors','erp_vendors']),
 'suppliers':('suppliers',['commerce_suppliers']),
 'orders':('erp_orders',['orders','commerce_orders','ecommerce_orders','sales_orders','sales_order_items']),
 'purchase_orders':('erp_purchase_orders',['purchase_orders','purchase_order_items','purchase_order_lines','acct_ap_purchase_orders','acct_ap_purchase_order_lines']),
 'goods_receipts':('erp_goods_receipts',['goods_receipts','goods_receipt_lines']),
 'invoices':('acct_ar_invoices',['invoices','invoice_items','recurring_invoices','recurring_invoice_items']),
 'bills':('acct_ap_bills',['bills','bill_items','vendor_invoices','vendor_invoice_lines']),
 'estimates':('acct_estimates',['estimates','estimate_items']),
 'receipts':('acct_ar_receipts',['receipts','receipt_items']),
 'ledger':('acct_journal_entries',['journal_entries','journal_lines','chart_of_accounts']),
 'banking':('acct_bank_accounts',['bank_accounts','bank_transactions','reconciliations']),
 'products':('products',['commerce_products','canonical_products?']),
 'promotions':('commerce_promotions',['promos','promo_redemptions','commerce_coupons','commerce_coupon_redemptions']),
 'saved_views':('platform_saved_views',['saved_views','crm_saved_views']),
 'carts':('commerce_carts',['carts','cart_items','commerce_cart_lines?']),
 'tasks':('crm_tasks',['ai_tasks?','verification_tasks?']),
}
dupof={}
for cl,(canon,others) in DUP.items():
    for o in others: dupof[o.rstrip('?')]=(cl,canon)
    dupof.setdefault(canon,(cl,canon+' (canonical)'))
OUT_SCOPE=re.compile(r'(pawzly|telemed|lms)')
rows=[]
allobj=prod|sept|full
for (k,sc,n,x) in sorted(allobj):
    if k=='column': continue
    qn=f'{sc}.{n}'
    if k=='function' and any(n.startswith(p) for p in ext_fns): continue
    tgt=qn if k in('table','view','matview','function') else qn
    dom=classify(qn)
    layer='production baseline (Nov 2 + Nov 3 hotfixes)' if (k,sc,n,x) in prod else ('September files (not deployed)' if (k,sc,n,x) in sept else 'Nov 9 delta')
    files=sorted(deffiles.get((k,qn),set()) | deffiles.get(('function' if k=='function' else k,qn),set()))
    if layer!='production baseline (Nov 2 + Nov 3 hotfixes)':
        files=[f for f in files if not f.startswith('2026110302') and not f.startswith('2026110303')]
    status='keep'; note=''
    bare=n if sc=='public' else qn
    if bare in dupof:
        cl,canon=dupof[bare]
        if canon.endswith('(canonical)'): status='canonical'; note=f'cluster: {cl}'
        else: status='consolidate'; note=f'cluster: {cl} -> {canon}'
    if OUT_SCOPE.search(n): status='remove'; note='leftover from another app (pre white-label)'
    if k=='function' and n in('acct_post_journal','acct_reverse_journal','current_tenant_id','current_tenant_ids','is_tenant_member','acct_audit_row_change','acct_block_posted_mutation'):
        note=(note+'; ' if note else '')+'September files REPLACE the production body - review before deploy'
        status='review'
    rows.append(dict(domain_id=dom,domain=NAMES.get(dom,'?'),object_type=k,schema=sc,name=n,detail=x,layer=layer,defined_in='; '.join(files) if layer!='production baseline (Nov 2 + Nov 3 hotfixes)' else 'baseline',status=status,note=note))
# app17 objects (not applied anywhere since it fails) from regex inventory
for r in inv:
    if r['eras']==['delta_nov09'] and 'app_17' in ' '.join(r['files']) and r['kind'] in('table','function','view'):
        sc,n=r['name'].split('.',1)
        rows.append(dict(domain_id='18',domain=NAMES['18'],object_type=r['kind'],schema=sc,name=n,detail='',layer='Nov 9 delta (fails to apply)',defined_in='; '.join(r['files']),status='blocked',note='app_17 fails: acct_journal_entries has entry_date AND posting_date'))
with open(W+'domain_manifest.csv','w',newline='') as fh:
    w=csv.DictWriter(fh,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
json.dump(rows,open(W+'manifest.json','w'))
c=collections.Counter((r['domain_id'],r['object_type'],r['layer']) for r in rows if r['object_type'] in('table','function'))
summ=collections.defaultdict(lambda: collections.Counter())
for (d,k,l),v in c.items(): summ[d][(k,l)]=v
for d in sorted(summ): print(d,NAMES.get(d),dict(summ[d]))
print(collections.Counter(r['status'] for r in rows if r['object_type']=='table'))
