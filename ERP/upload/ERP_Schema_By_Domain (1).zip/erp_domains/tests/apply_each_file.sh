# usage: applytest.sh dbname file1 file2 ...  (applies sequentially, stop-on-error per file, continues to next file)
db=$1; shift
for f in "$@"; do
  out=$(psql -h /tmp -p 5499 -U postgres -d $db -q -v ON_ERROR_STOP=1 -f "$f" 2>&1); rc=$?
  err=$(echo "$out" | grep -m1 -E 'ERROR|FATAL' | sed 's/.*ERROR: *//' | cut -c1-160)
  line=$(echo "$out" | grep -m1 -oE 'sql:[0-9]+' )
  printf "%s\t%s\t%s\t%s\n" "$(basename "$f")" "$([ $rc = 0 ] && echo OK || echo FAIL)" "$line" "$err"
done
