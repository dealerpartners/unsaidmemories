-- Scenario tests for App Part 19 (cap table ledger + 409A). Run on a scratch database that has
-- production + Sept release + App 19 applied:  psql -v ON_ERROR_STOP=1 -f test_app19_cap_409a.sql
-- Every check raises on failure; the last line prints ALL APP 19 TESTS PASSED.
\set QUIET on
\pset tuples_only on
\pset format unaligned
SET client_min_messages = warning;

CREATE OR REPLACE FUNCTION pg_temp.expect_fail(p_sql text, p_pattern text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  BEGIN
    EXECUTE p_sql;
  EXCEPTION WHEN others THEN
    IF SQLERRM !~* p_pattern THEN RAISE EXCEPTION 'expected error /%/, got: %', p_pattern, SQLERRM; END IF;
    RAISE NOTICE 'ok (blocked): %', left(SQLERRM, 110);
    RETURN;
  END;
  RAISE EXCEPTION 'expected failure /%/ but statement succeeded: %', p_pattern, left(p_sql, 120);
END $$;
CREATE OR REPLACE FUNCTION pg_temp.ok(p_cond boolean, p_label text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF NOT coalesce(p_cond, false) THEN RAISE EXCEPTION 'check failed: %', p_label; END IF; RAISE NOTICE 'ok: %', p_label; END $$;
CREATE OR REPLACE FUNCTION pg_temp.as_user(p_user uuid) RETURNS void LANGUAGE plpgsql AS $$
BEGIN PERFORM set_config('request.jwt.claim.sub', p_user::text, false); PERFORM set_config('request.jwt.claim.role', 'authenticated', false);
      EXECUTE 'SET ROLE authenticated'; END $$;
GRANT EXECUTE ON FUNCTION pg_temp.expect_fail(text,text), pg_temp.ok(boolean,text), pg_temp.as_user(uuid) TO authenticated;
SET client_min_messages = notice;

-- ---------- fixtures (superuser) ----------
INSERT INTO auth.users(id, email) VALUES
  ('a0000000-0000-0000-0000-00000000000a','owner@test.dev'),
  ('a0000000-0000-0000-0000-00000000000b','staff@test.dev'),
  ('a0000000-0000-0000-0000-00000000000c','founder@test.dev');
INSERT INTO tenants(id, name, slug, type) VALUES ('70000000-0000-0000-0000-000000000001','Test Co','test-co','seller');
INSERT INTO tenant_memberships(tenant_id, user_id, role, active, status) VALUES
  ('70000000-0000-0000-0000-000000000001','a0000000-0000-0000-0000-00000000000a','owner',true,'active'),
  ('70000000-0000-0000-0000-000000000001','a0000000-0000-0000-0000-00000000000b','staff',true,'active');
INSERT INTO acct_currencies(code, name, symbol, tenant_id) VALUES ('USD','US Dollar','$','70000000-0000-0000-0000-000000000001') ON CONFLICT DO NOTHING;  -- seed data (schema-only test db)
INSERT INTO acct_entities(id, tenant_id, code, legal_name, functional_currency)
VALUES ('e0000000-0000-0000-0000-000000000001','70000000-0000-0000-0000-000000000001','TC','Test Co, Inc.','USD');

-- ---------- owner sets up the company ----------
SELECT pg_temp.as_user('a0000000-0000-0000-0000-00000000000a');
INSERT INTO cap_issuer_profiles(tenant_id, entity_id, state_of_incorporation, incorporated_on)
VALUES ('70000000-0000-0000-0000-000000000001','e0000000-0000-0000-0000-000000000001','DE','2024-01-15');
INSERT INTO cap_stakeholders(id, tenant_id, name, email, stakeholder_type, user_id) VALUES
  ('5a000000-0000-0000-0000-000000000001','70000000-0000-0000-0000-000000000001','Fran Founder','founder@test.dev','founder','a0000000-0000-0000-0000-00000000000c'),
  ('5a000000-0000-0000-0000-000000000002','70000000-0000-0000-0000-000000000001','Eve Employee','eve@test.dev','employee',NULL);
INSERT INTO cap_share_classes(id, tenant_id, entity_id, name, class_type, authorized_shares, par_value)
VALUES ('c1000000-0000-0000-0000-000000000001','70000000-0000-0000-0000-000000000001','e0000000-0000-0000-0000-000000000001','Common','common',10000000,0.00001);
INSERT INTO cap_option_pools(id, tenant_id, share_class_id, name, authorized_shares, adopted_on, shareholder_approved_on)
VALUES ('900f0000-0000-0000-0000-000000000001','70000000-0000-0000-0000-000000000001','c1000000-0000-0000-0000-000000000001','2026 Plan',1000000,'2026-01-05','2026-01-05');
INSERT INTO cap_vesting_schedules(id, tenant_id, name, total_months, cliff_months, frequency_months, is_default)
VALUES ('5c000000-0000-0000-0000-000000000001','70000000-0000-0000-0000-000000000001','4y monthly, 1y cliff',48,12,1,true);

-- founder restricted stock (no journal in this test), 83(b) window set automatically
SELECT cap_issue_shares('70000000-0000-0000-0000-000000000001','5a000000-0000-0000-0000-000000000001','c1000000-0000-0000-0000-000000000001',
       8000000, 0.00001, '2024-01-20', 'cash', NULL, NULL, NULL, NULL, NULL, false, '2024-01-20', 48, 12, NULL) AS founder_issuance \gset
SELECT pg_temp.ok((SELECT form_83b_due_on = '2024-02-19' FROM cap_issuances WHERE id = :'founder_issuance'), '83(b) due date = issue date + 30');

-- no 409A yet: grants are blocked
SELECT pg_temp.expect_fail($$SELECT cap_grant_options('900f0000-0000-0000-0000-000000000001','5a000000-0000-0000-0000-000000000002',10000,0.10,'2026-02-01')$$,
                           'No 409A valuation covers');

-- ---------- 409A: illiquid start-up method ----------
INSERT INTO cap_documents(id, tenant_id, entity_id, document_type, title, status) VALUES
  ('d0000000-0000-0000-0000-000000000001','70000000-0000-0000-0000-000000000001','e0000000-0000-0000-0000-000000000001','409a_report','409A report 2026-03-01','signed');
INSERT INTO cap_qualified_individuals(id, tenant_id, entity_id, full_name, qualifications_summary, years_experience, experience_categories)
VALUES ('91000000-0000-0000-0000-000000000001','70000000-0000-0000-0000-000000000001','e0000000-0000-0000-0000-000000000001',
        'Val Uator','CFA; 6 years business valuation',6,'{business_valuation}');
INSERT INTO cap_board_approvals(id, tenant_id, entity_id, approval_type, adopted_on) VALUES
  ('ba000000-0000-0000-0000-000000000001','70000000-0000-0000-0000-000000000001','e0000000-0000-0000-0000-000000000001','valuation_adopt','2026-03-10'),
  ('ba000000-0000-0000-0000-000000000002','70000000-0000-0000-0000-000000000001','e0000000-0000-0000-0000-000000000001','grant_batch','2026-03-10');

SELECT val_open_request('70000000-0000-0000-0000-000000000001','2026-03-01','illiquid_startup','e0000000-0000-0000-0000-000000000001',
                        '91000000-0000-0000-0000-000000000001','In-house') AS req \gset
SELECT pg_temp.ok((SELECT (gate_check->>'passes')::boolean AND snapshot_id IS NOT NULL FROM val_requests WHERE id = :'req'), 'start-up gate passes; cap table frozen');

INSERT INTO val_approaches(tenant_id, request_id, method, equity_value, weight_pct, rejected, rationale) VALUES
  ('70000000-0000-0000-0000-000000000001', :'req', 'asset', 400000, 0, true, 'Going concern; asset approach not indicative'),
  ('70000000-0000-0000-0000-000000000001', :'req', 'dcf', 4500000, 40, false, 'Management projections'),
  ('70000000-0000-0000-0000-000000000001', :'req', 'market_guideline', 5333333.33, 50, false, 'EV/revenue comps');
SELECT pg_temp.expect_fail(format($$SELECT val_draft_report(%L)$$, :'req'), 'weights add to');
UPDATE val_approaches SET weight_pct = 60 WHERE request_id = :'req' AND method = 'market_guideline';
SELECT pg_temp.expect_fail(format($$SELECT val_draft_report(%L)$$, :'req'), 'equity allocation');
INSERT INTO val_allocations(tenant_id, request_id, method, equity_value_in, volatility, time_to_liquidity_yrs, risk_free_rate, common_per_share_marketable)
VALUES ('70000000-0000-0000-0000-000000000001', :'req', 'opm', 5000000, 0.60, 3, 0.04, 0.60);
INSERT INTO val_dlom(tenant_id, request_id, model, dlom_pct, rationale)
VALUES ('70000000-0000-0000-0000-000000000001', :'req', 'finnerty', 25, 'Finnerty, 3 years, 60% volatility');
SELECT val_draft_report(:'req', '2026-03-05') AS rpt \gset
SELECT pg_temp.ok((SELECT fmv_per_share_common = 0.45 FROM val_reports WHERE id = :'rpt'), 'FMV = 0.60 x (1 - 25%) = 0.45');

SELECT pg_temp.expect_fail(format($$SELECT val_adopt_report(%L, 'ba000000-0000-0000-0000-000000000002')$$, :'rpt'), 'valuation_adopt');
SELECT pg_temp.expect_fail(format($$SELECT val_adopt_report(%L, 'ba000000-0000-0000-0000-000000000001')$$, :'rpt'), 'written valuation report');
SELECT val_draft_report(:'req', '2026-03-05', 'd0000000-0000-0000-0000-000000000001');
SELECT val_adopt_report(:'rpt', 'ba000000-0000-0000-0000-000000000001') AS val \gset
SELECT pg_temp.ok((SELECT expires_on = '2027-02-28' AND status = 'final' AND method = 'illiquid_startup' FROM cap_valuations WHERE id = :'val'),
                  '409A of record valid 12 months (to 2027-02-28)');
SELECT pg_temp.expect_fail(format($$UPDATE val_reports SET fmv_per_share_common = 0.30 WHERE id = %L$$, :'rpt'), 'cannot be edited|permission denied');

-- ---------- grant guards ----------
SELECT pg_temp.expect_fail($$SELECT cap_grant_options('900f0000-0000-0000-0000-000000000001','5a000000-0000-0000-0000-000000000002',10000,0.40,'2026-04-01')$$,
                           'below');
SELECT cap_grant_options('900f0000-0000-0000-0000-000000000001','5a000000-0000-0000-0000-000000000002',48000,0.45,'2026-04-01',
                         NULL,48,12,'iso','d0000000-0000-0000-0000-000000000001') AS g1 \gset
SELECT pg_temp.ok((SELECT valuation_id = :'val' AND val_report_id = :'rpt' FROM cap_option_grants WHERE id = :'g1'), 'grant linked to the 409A it relied on');
SELECT pg_temp.ok((SELECT sum(shares_vesting) = 48000 AND count(*) FILTER (WHERE shares_vesting > 0) = 37 FROM cap_vesting_schedule(:'g1')),
                  'vesting schedule: cliff + 36 monthly tranches = 48,000');
-- founder holds 100% of votes: ISO needs 110% of FMV and a 5-year term
SELECT pg_temp.expect_fail($$SELECT cap_grant_options('900f0000-0000-0000-0000-000000000001','5a000000-0000-0000-0000-000000000001',10000,0.45,'2026-04-01')$$,
                           '110%');
SELECT cap_grant_options('900f0000-0000-0000-0000-000000000001','5a000000-0000-0000-0000-000000000001',10000,0.50,'2026-04-01') AS g2 \gset
SELECT pg_temp.ok((SELECT expires_on = '2031-04-01' FROM cap_option_grants WHERE id = :'g2'), '10% holder ISO capped at 5-year term');

-- a sale anticipated within 90 days breaks the start-up presumption at grant time
UPDATE cap_issuer_profiles SET anticipated_change_in_control_on = '2026-06-01' WHERE entity_id = 'e0000000-0000-0000-0000-000000000001';
SELECT pg_temp.expect_fail($$SELECT cap_grant_options('900f0000-0000-0000-0000-000000000001','5a000000-0000-0000-0000-000000000002',1000,0.45,'2026-04-15')$$,
                           'no_cic_within_90_days');
UPDATE cap_issuer_profiles SET anticipated_change_in_control_on = NULL WHERE entity_id = 'e0000000-0000-0000-0000-000000000001';

-- material event ends reliance the day before
INSERT INTO val_material_events(tenant_id, entity_id, event_type, event_date, description, triggers_revaluation)
VALUES ('70000000-0000-0000-0000-000000000001','e0000000-0000-0000-0000-000000000001','term_sheet','2026-06-15','Series A term sheet signed',true);
SELECT pg_temp.ok((SELECT expires_on = '2026-06-14' FROM cap_valuations WHERE id = :'val'), 'material event cut validity to 2026-06-14');
SELECT pg_temp.expect_fail($$SELECT cap_grant_options('900f0000-0000-0000-0000-000000000001','5a000000-0000-0000-0000-000000000002',1000,0.45,'2026-07-01')$$,
                           'No 409A valuation covers');
SELECT cap_grant_options('900f0000-0000-0000-0000-000000000001','5a000000-0000-0000-0000-000000000002',1000,0.45,'2026-06-10') IS NOT NULL AS still_ok_before_event \gset
SELECT pg_temp.ok(:'still_ok_before_event'::boolean, 'grants dated before the event still rely on the valuation');

-- ledger tables are function-only even for the owner
SELECT pg_temp.expect_fail($$INSERT INTO cap_option_grants(tenant_id,pool_id,stakeholder_id,granted_on,shares,exercise_price,vesting_start)
  VALUES ('70000000-0000-0000-0000-000000000001','900f0000-0000-0000-0000-000000000001','5a000000-0000-0000-0000-000000000002','2026-04-01',1,0.45,'2026-04-01')$$,
  'permission denied');
SELECT pg_temp.expect_fail($$DELETE FROM cap_equity_events$$, 'permission denied');

SELECT pg_temp.ok((cap_verify_event_chain('70000000-0000-0000-0000-000000000001')->>'valid')::boolean, 'equity event hash chain verifies');
SELECT pg_temp.ok(EXISTS (SELECT 1 FROM cap_compliance_check('70000000-0000-0000-0000-000000000001','2026-07-01') WHERE check_code = '83b_overdue'),
                  'compliance check flags the missing founder 83(b)');
SELECT pg_temp.ok(EXISTS (SELECT 1 FROM cap_compliance_check('70000000-0000-0000-0000-000000000001','2026-07-01') WHERE check_code = 'valuation_stale_after_event'),
                  'compliance check flags the unrefreshed valuation');
SELECT pg_temp.ok((SELECT count(*) >= 3 FROM cap_table('70000000-0000-0000-0000-000000000001','2026-07-01')), 'owner sees the cap table');
RESET ROLE;

-- ---------- staff member: no equity visibility, no writes ----------
SELECT pg_temp.as_user('a0000000-0000-0000-0000-00000000000b');
SELECT pg_temp.ok((SELECT count(*) = 0 FROM cap_issuances) AND (SELECT count(*) = 0 FROM cap_option_grants) AND (SELECT count(*) = 0 FROM val_reports),
                  'staff member sees no equity rows');
SELECT pg_temp.expect_fail($$SELECT * FROM cap_table('70000000-0000-0000-0000-000000000001')$$, 'owners and admins');
SELECT pg_temp.expect_fail($$SELECT * FROM cap_liquidation_waterfall('70000000-0000-0000-0000-000000000001', 1000000)$$, 'owners and admins');
SELECT pg_temp.expect_fail($$INSERT INTO cap_stakeholders(tenant_id,name,stakeholder_type) VALUES ('70000000-0000-0000-0000-000000000001','X','other')$$,
                           'row-level security');
RESET ROLE;

-- ---------- founder (holder, not a team member): own holdings only ----------
SELECT pg_temp.as_user('a0000000-0000-0000-0000-00000000000c');
SELECT pg_temp.ok((SELECT count(*) = 1 FROM cap_stakeholders), 'holder sees only their stakeholder record');
SELECT pg_temp.ok((SELECT count(*) = 1 FROM cap_issuances) AND (SELECT count(*) = 1 FROM cap_option_grants), 'holder sees only their own shares and grant');
SELECT pg_temp.ok((SELECT count(*) = 2 FROM cap_my_holdings('2026-07-01')), 'cap_my_holdings returns shares + option');
SELECT pg_temp.expect_fail($$SELECT * FROM cap_table('70000000-0000-0000-0000-000000000001')$$, 'owners and admins');
SELECT cap_record_83b_filing(:'founder_issuance', '2024-02-10');
RESET ROLE;

-- ---------- tamper detection and registry re-run (superuser) ----------
SELECT count(*) AS reapplied FROM platform__apply_app_security() \gset
SELECT pg_temp.as_user('a0000000-0000-0000-0000-00000000000b');
SELECT pg_temp.ok((SELECT count(*) = 0 FROM cap_issuances), 'equity policies survive a registry security re-run');
RESET ROLE;
SET app.allow_tenant_purge = 'on';
UPDATE cap_equity_events SET shares = shares + 1 WHERE tenant_id = '70000000-0000-0000-0000-000000000001' AND event_type = 'grant'
   AND seq = (SELECT min(seq) FROM cap_equity_events WHERE event_type = 'grant' AND tenant_id = '70000000-0000-0000-0000-000000000001');
RESET app.allow_tenant_purge;
SELECT set_config('request.jwt.claim.role', 'service_role', false);
SELECT pg_temp.ok(NOT (cap_verify_event_chain('70000000-0000-0000-0000-000000000001')->>'valid')::boolean, 'tampered event detected by chain check');

\echo ALL APP 19 TESTS PASSED
