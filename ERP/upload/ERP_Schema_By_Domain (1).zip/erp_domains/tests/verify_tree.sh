#!/usr/bin/env bash
# Rebuild a domain tree into one file, load it into a scratch Postgres that has Supabase stand-ins,
# and diff the resulting schema against a reference database.  Usage: verify_tree.sh TREE_DIR REFERENCE_DB
set -euo pipefail
TREE=$1; REF=$2; P="-h ${PGHOST:-/tmp} -p ${PGPORT:-5499} -U ${PGUSER:-postgres}"
python3 "$(dirname "$0")/../tools/assemble.py" "$TREE" /tmp/_tree.sql
sed -E 's/^CREATE EXTENSION IF NOT EXISTS "?(pg_cron|pg_net|supabase_vault)"?.*;/-- &/' /tmp/_tree.sql > /tmp/_tree_local.sql
dropdb $P --if-exists _verify; createdb $P _verify
psql $P -d _verify -q -f "$(dirname "$0")/supabase_stub.sql" >/dev/null 2>&1
psql $P -d _verify -q -f /tmp/_tree_local.sql 2>&1 | grep -c ERROR || true
X="-N auth -N cron -N vault -N net -N storage -N extensions"
diff <(pg_dump $P -s --no-owner $X "$REF" | grep -vE '^(--|\\(un)?restrict)' | sed '/^$/d') \
     <(pg_dump $P -s --no-owner $X _verify   | grep -vE '^(--|\\(un)?restrict)' | sed '/^$/d') && echo "IDENTICAL"
