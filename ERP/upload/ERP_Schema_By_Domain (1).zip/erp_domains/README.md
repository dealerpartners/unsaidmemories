# ERP Schema Organized by App Domain

Prepared November 9, 2026, from the 27 SQL files in the ERP project. Every result below comes from actually running the SQL in a scratch PostgreSQL 18 database. That database has stand-ins for Supabase's `auth`, `vault`, `cron` and `net` schemas and its roles.

## What's in this package

| Path | Contents |
|---|---|
| `schema_current/` | Production as exported on Nov 2 (`20261103010000`–`030000`), split into 30 domain folders |
| `schema_target/` | Production + Nov 3 hotfixes + the 16 September files that deploy cleanly + Nov 9 app_16 and app_18, split the same way |
| `domain_manifest.csv` | 5,393 objects (tables, views, functions, triggers, policies), each with its domain, layer, source file, status and notes |
| `domain_fk_deps.json` | Count of foreign keys from each domain to every other domain |
| `tools/split_by_domain.py` | Splits any generated schema (Supabase catalog export or `pg_dump -s`) into domain folders |
| `tools/assemble.py` | Rebuilds one executable SQL file from a domain tree, in the original dependency order |
| `tools/domains.py` | The domain rules (one ordered regex list; edit here to move objects) |
| `migrations/` | App Part 19, the cap table and 409A migration (replaces `409a-cap-table-schema.sql`) |
| `tests/` | App Part 19 scenario tests, deploy test results, the Supabase stand-in, the per-file apply script, and the tree verifier |

Verification: both trees were rebuilt with `assemble.py`, loaded into an empty database, and dumped again. The rebuilt schema is identical to the source:
- **Current tree:** 5,363 statements; 735 tables, 1,199 policies, 2,338 indexes.
- **Target tree:** 12,168 statements; 902 tables, 3,439 policies, 549 functions.
- **Result:** 0 errors and 0 lines of schema difference for both.

---

## Update: production status and cap table (Nov 9, 2026)

**What's in production, as you described it:**
- **Live:** schema parts 1–3, all Nov 3 hotfixes, and the rules engine.
- **Never run:** the 409A file, Finance Parts 1–9 and App Parts 10–15. These all wait for the September release (R1).

**Rules engine: please confirm.** None of `rules_engine.sql`'s objects are in the Nov 2 export (Supabase project `pcwwvfgxnrglmmpbfqhf`):
- It creates `bulk_jobs`, `saved_views`, `season_windows`, the `product_facts` view, 8 functions and 2 enum types. None of them are in the export.
- The live `collections` table has a different shape (`tenant_id, type, slug, starts_on, ends_on, parent_id, owner_id`). It has no `rule`, `pinned` or `excluded` columns.
- The engine also expects `canonical_products.title`, `brand` and `child_id`. Production has none of them.

So the rules engine either ran in a different Supabase project or ran after Nov 2. This query on production settles it:
`select proname from pg_proc where proname in ('apply_bulk','preview_rule','rule_where');`

**Cap table: built as App Part 19.** Run `migrations/20261109190000_app_19_cap_table_409a.sql` instead of `409a-cap-table-schema.sql`. This replaces the earlier recommendation (R4 below) to adopt the 409A file's model and turn Part 14's tables into views. Reading both designs in full showed that Part 14 is the stronger base:
- Part 14 is tenant- and entity-scoped, joined to the party hub, and posts issuances, conversions and SAFEs to the ledger.
- The 409A file has no `tenant_id`, no RLS and no ledger link, and it defers its guards to the app.

App Part 19 extends Part 14 with everything the 409A design added:
- **New records:** an issuer profile, board approvals, qualified individuals, vesting templates, and frozen cap table snapshots.
- **Valuation workflow:** the full set of `val_*` tables, from request to adopted report.
- **Tamper-evident ledger:** a hash chain on `cap_equity_events`.
- **Rules enforced in the database:** 12-month validity, cutoff at material events, the start-up safe-harbor tests (rechecked on the grant date), FMV and 110%/5-year limits on ISO grants, and 83(b) deadlines.

**Access in App Part 19:**
- Cap table data is admin-only. Staff see nothing, and stakeholders see only their own holdings.
- The equity records themselves (issuances, grants, events, valuations) can be written only through the cap table functions.

**Test result:** applied on production + the September files + app_16 + app_18, run twice with no errors, and passes all 35 checks in `tests/test_app19_cap_409a.sql`.

**Data issues the tests surfaced:**
- `tenant_memberships.role` still allows `groomer` and `front_desk` (left over from Pawzly).
- `acct_currencies.tenant_id` defaults to a hard-coded tenant UUID.

---

## 1. What the deploy test showed

1. **The September files were never deployed to production.** Production on Nov 2 shares only 1 table and 7 functions with them. Missing from production as a result:
   - The bank rules, close, AP vendor credits, cap table, MeF/e-file, Teller and integration tables.
   - `platform_parties` and `platform_canonical_map`.
   - 143 tables and 423 functions in total.
2. **16 of the 18 September files deploy cleanly** on top of production (Finance 1–9, App 10–15, `unsaid_consolidated_tax_calculations.sql`).
3. **Two September files fail:**
   - `rules_engine.sql`: it expects `canonical_products.child_id`, but production's `canonical_products` has only `id, sku_slug, name, category, created_at`. It needs rewriting against the current catalog model.
   - `409a-cap-table-schema.sql`: `cap_stakeholders` already exists (App Part 14 creates it). These are two different cap table designs (Section 4, domain 19).
4. **All three Nov 9 files fail against production**, because they depend on September objects:
   - `app_16` needs `integration_connections`, `teller_enrollments` and `mef_returns`.
   - `app_18` needs `acct_can_access(uuid)`.
   - After the September files are applied, app_16 and app_18 succeed.
   - `app_17` still fails. `acct_journal_entries` has both `entry_date` and `posting_date`, and the "date adapter" refuses to guess. Fix: hard-code `posting_date` (the accounting-period date).
5. **The September files replace 7 live production functions with different code:**
   - `acct_post_journal` and `acct_reverse_journal`: same signatures, different bodies.
   - `current_tenant_id`, `current_tenant_ids` and `is_tenant_member`, which drive about 1,000 RLS policies.
   - `acct_audit_row_change` and `acct_block_posted_mutation`.
   - These need a line-by-line review before deploy. They are marked `review` in the manifest.
6. **Leftovers from before the white-label rename:**
   - 37 production functions have `'lms'` in their `search_path`.
   - 4 functions belong to other apps (`pawzly_bump_session`, `telemed_audit_log_immutable`, `assign_lms_role`, `revoke_lms_role`).
   - The Nov 2 export also includes `pg_trgm`'s internal functions (`gtrgm_*`, `similarity*`). Those belong to the extension and should be left out of the export.
7. **RLS gaps:**
   - Production has 3 tables without RLS: `ad_events`, `supplier_category_memory`, `supplier_category_visibility`. App Part 10 fixes all three.
   - If the 409A file is run without a transaction, it leaves `cap_companies` behind without RLS.
8. **Unindexed foreign keys:** about 300 in production and about 950 after the September files. That number is approximate, since it only checks the leading index columns.

---

## 2. How to work from now on

**Don't reorganize the handwritten migration files themselves.** They are procedural (DO blocks, guarded ALTERs, data backfills) and they cross domains. Split the database's generated schema instead, and treat it as the domain-organized source of truth:

```
1. Apply migrations to a staging copy of production
2. Export the schema       ->  pg_dump -s --no-owner (or the Supabase catalog export)
3. Split by domain         ->  python3 tools/split_by_domain.py schema/ dump.sql
4. Verify                  ->  tests/verify_tree.sh schema/ staging_db   (must print IDENTICAL)
5. Commit schema/ alongside the migration that produced it
```

New changes get one migration per domain, named `YYYYMMDDHHMM_<domain-id>_<description>.sql` (for example `202611101200_11_period_lock_guard.sql`). A migration may touch only its own domain's objects, plus foreign keys pointing into domains it depends on. The re-split tree then shows reviewers exactly which domain files changed.

Suggested repo layout:
```
db/
  migrations/            # immutable history: baseline_20261102, september_*, nov09_*, then per-domain deltas
  schema/                # generated domain tree (schema_target after the September release)
  tools/  tests/
  domain_manifest.csv    # regenerated with tools/build_manifest.py
```

---

## 3. Domains

Counts are tables / functions. "Current" is production plus the Nov 3 hotfixes. "Added" is what the September files and the Nov 9 deltas bring. "Consolidate" counts tables that duplicate a canonical table.

| ID | Domain | App navigation it serves | Current T / F | Added T / F | Consolidate |
|---|---|---|---|---|---|
| 00 | Foundation | Extensions, enums, sequences, shared helpers | — | — | — |
| 01 | Platform & Workspace | Settings → Workspace, registry, quick actions, saved views | 46 / 14 | 8 / 41 | 5 |
| 02 | Identity, Access & Security | Teammates, roles, portals, admin, sessions | 20 / 6 | 0 / 0 | 0 |
| 03 | Contacts: Parties & CRM | Parties (Customer/Vendor/Supplier), leads, segments, templates | 55 / 1 | 3 / 3 | 6 |
| 04 | Marketplace Sellers | Sellers, seller detail/feed, onboarding queue | 38 / 2 | 0 / 0 | 1 |
| 05 | Catalog & Products | Products & variants, bundles, categories, brands, supplier catalog | 56 / 22 | 0 / 0 | 1 |
| 06 | Design Studio | Konva studio, designs, mockups, print specs | 9 / 0 | 0 / 0 | 0 |
| 07 | Storefront, Checkout & Channels | Ecommerce channels, carts, checkout, loyalty, store credit | 78 / 1 | 0 / 0 | 15 |
| 08 | Orders & Fulfillment | Orders, order detail, packing slips, shipping settings, carriers | 39 / 6 | 0 / 7 | 3 |
| 09 | Purchasing & Inventory | Purchase orders, receiving, inventory, cycle counts, replenishment | 37 / 7 | 0 / 12 | 12 |
| 10 | Returns & Claims | Returns/RMA, inspections, return refunds | 9 / 0 | 0 / 4 | 1 |
| 11 | Finance: Ledger, Close & Consolidation | Chart of accounts, journals, periods, close, budgets, review | 37 / 12 | 20 / 228 | 5 |
| 12 | Finance: Banking & Treasury | Bank transactions, rules, reconcile, deposits, transfers, loans/LOC, settlements, Teller | 14 / 0 | 18 / 16 | 5 |
| 13 | Finance: Sales & Receivables | Invoices, payment links, receive payment, statements, estimates, credit memos, revenue recognition | 32 / 4 | 7 / 3 | 15 |
| 14 | Finance: Expenses & Payables | Bills, pay bills, expenses, checks, vendor credits, receipt capture | 14 / 2 | 8 / 4 | 6 |
| 15 | Finance: Items, Fixed Assets & Leases | Products/services (accounting side), fixed assets, leases, cost layers | 7 / 0 | 5 / 8 | 3 |
| 16 | Team: Payroll, Contractors & Time | Contractors/1099, payroll, time entry, staff, commissions | 30 / 1 | 3 / 4 | 10 |
| 17 | Sales Tax | Tax codes, rates, nexus, exemptions, filings | 11 / 0 | 7 / 5 | 0 |
| 18 | Business Tax & E-file | Business tax overview, tax summary, MeF, tax16/calc17/partnership18/taxprod | 0 / 0 | 53 / 89 | 4 |
| 19 | Cap Table & Valuation | Stakeholders, rounds, option pool, SAFEs, 409A | 0 / 0 | 11 / 16 | 0 (but two designs) |
| 20 | Website / CMS | CMS pages, content blocks, banners, popups, SEO, navigation | 48 / 1 | 1 / 0 | 1 |
| 21 | Marketing: Social, Email & Promotions | Social studio, newsletter, email, promotions & discounts | 26 / 1 | 5 / 5 | 4 |
| 22 | Advertising | Ad center, campaigns, ad sets, creatives, audiences | 36 / 2 | 0 / 0 | 0 |
| 23 | Support, Trust & Safety | Tickets, inbox, queues, SLA, KB, DMCA, policies | 58 / 13 | 0 / 0 | 2 |
| 24 | Community, Reviews & UGC | Reviews, Q&A, UGC posts | 10 / 4 | 0 / 0 | 0 |
| 25 | Tasks, Chat & Notifications | Tasks board/list/calendar, personal chat, announcements | 5 / 0 | 7 / 0 | 0 |
| 26 | Reports & Analytics | Analytics, explorer, search events, GA4 | 7 / 2 | 0 / 0 | 0 |
| 27 | Integrations, Jobs & Events | Settings → Integrations, API keys, sync jobs, webhooks | 11 / 4 | 4 / 0 | 2 |
| 28 | AI | AI agents, gateway, disclosures | 9 / 1 | 2 / 2 | 1 |
| 99 | Out of scope | Leftovers from other apps | 0 / 4 | — | remove |

**Dependency shape (from 1,283 production foreign keys):**
- Every domain depends on 01 (457 incoming FKs: tenants, locations, registry).
- The other hubs are 11 Ledger (56), 05 Catalog (51) and 03 Parties (49).
- Finance domains 12–15 depend on 11. Orders (08) depends on Catalog (05) and Storefront (07).
- Support (23) and CRM (03) point at 16 because `crm_staff` lives there. That's an argument for making "staff" a party role in 03 (see employees cluster below).

---

## 4. Duplicates to eliminate, by owning domain

Each row names the canonical table; everything else in the row should become a view or be retired. The manifest marks them `canonical` and `consolidate`.

| Domain | Canonical | Retire or convert to a view |
|---|---|---|
| 01 | `platform_saved_views` | `saved_views`, `crm_saved_views` |
| 01 | `platform_audit_events` (new, partitioned) | `acct_/cms_/commerce_/crm_/erp_audit_log`, `activity_log` |
| 01 | `platform_idempotency_keys` (new) | `acct_integration_idempotency`, `commerce_idempotency`, `crm_idempotency_keys`, `erp_idempotency_keys` |
| 03 | `crm_customers` + `platform_parties` | `customers`, `acct_customers`, `commerce_customer_accounts`, `order_customers` |
| 03 | `acct_vendors` (as a party role) | `vendors`, `erp_vendors` |
| 05 | `suppliers` | `commerce_suppliers` |
| 05 | `products` | `commerce_products`; decide whether `canonical_products` is a separate supplier-catalog object |
| 07 | `commerce_carts` | `carts`, `cart_items` |
| 07 | `commerce_gift_cards` | `acct_gift_cards`, `acct_gift_card_transactions` (GL postings only) |
| 07/13 | `commerce_refunds`, `commerce_disputes` | `acct_refunds`, `erp_return_refunds`, `acct_disputes` |
| 07 | `commerce_subscriptions` | `subscriptions`, `subscription_plans` (keep `platform_account_subscriptions` for your own SaaS billing) |
| 08 | `erp_orders` | `orders`, `commerce_orders`, `ecommerce_orders`, `sales_orders`, `sales_order_items` |
| 09 | `erp_purchase_orders` | `purchase_orders`, `purchase_order_items`, `purchase_order_lines`, `acct_ap_purchase_orders`(+lines) |
| 09 | `erp_goods_receipts` | `goods_receipts`, `goods_receipt_lines` |
| 09 | `erp_inventory_movements` (quantity ledger) | `inventory_items/levels/transactions`, `commerce_inventory_events`, `erp_inventory_transactions`, `erp_stock_levels` |
| 09/15 | `erp_inventory_cost_layers` | `acct_inventory_layers`, `acct_inventory_layer_draws`, `acct_inventory_moves` |
| 11 | `acct_journal_entries/lines`, `acct_chart_of_accounts` | `journal_entries`, `journal_lines`, `chart_of_accounts` |
| 12 | `acct_bank_accounts` and related | `bank_accounts`, `bank_transactions`, `reconciliations` |
| 13 | `acct_ar_invoices`, `acct_ar_receipts`, `acct_estimates`, `acct_customer_statements` | `invoices`, `invoice_items`, `recurring_invoices`(+items), `receipts`, `receipt_items`, `estimates`, `estimate_items`, `customer_statements` |
| 13 | `acct_revenue_recognition_schedules` | `acct_recognition_schedules`, `acct_recognition_lines` |
| 14 | `acct_ap_bills` | `bills`, `bill_items`, `vendor_invoices`, `vendor_invoice_lines` |
| 16 | `acct_employees` (party role) | `acct_payroll_employees`, `payroll_employees`, `staff`; `crm_staff` becomes the staff profile only |
| 16 | `acct_payroll_runs`, `acct_payroll_tax_forms` | `payroll_runs`, `payroll_run_items`, `payroll_tax_forms` |
| 16 | `acct_time_entries` (+`source_module`) | `acct_timesheets`, `payroll_timesheets`, `crm_staff_time_clock_entries`, `support_time_entries` |
| 18 | `calc.runs` (new single entry point, gap F01) | `tax16.calculation_runs`, `calc17.runs`, `partnership18.runs`, `taxprod.runs` |
| 19 | One cap-table model | App Part 14 (`cap_issuances`, `cap_option_grants`…) vs. the 409A file (ledger-first `cap_securities`, `cap_transactions`, `cap_grants`, vesting, plus all `val_*`). Recommendation: keep the 409A ledger-first model and its `val_*` tables, and turn App Part 14's tables into views over it |
| 21 | `commerce_promotions` | `promos`, `promo_redemptions`, `commerce_coupons`, `commerce_coupon_redemptions` |
| 27 | `integration_webhook_inbox`, `platform_outbox` (new), `platform_jobs` (new) | `stripe_/paypal_/commerce_webhook_events`; `commerce_/social_outbox_events`, `email_outbox`; `sync_jobs`, `support_jobs`, `provider_jobs`, `tax16.jobs` |

`platform_canonical_map` (App Part 13) already lists 38 of these, but it's a September object that isn't in production yet. Once deployed, add the remaining rows and a trigger that blocks inserts into any table whose lifecycle is `legacy`.

---

## 5. Gap ownership

Each gap ID from the gap register (F/T/P/S/G/D plus X/R/A/B/M/Q) is assigned to one owning domain, so "all gaps closed" can be checked domain by domain.

| Domain | Owns these gaps |
|---|---|
| 01 Platform | F02, X02 document lifecycle, X04 approval matrix, X07 job queue, X09 retention/legal hold, X11 office hours/multilingual |
| 02 Identity | X05 segregation of duties, X06 encrypted bank/TIN data, X10 external access and scoped API tokens |
| 03 Parties | Party unification (customers/vendors/suppliers/staff as roles) |
| 05/06 Catalog/Design | M04 design → product → listing lineage; rewrite `rules_engine.sql` |
| 08 Orders | Carrier "Test rates" integration; shipping-label provider |
| 09 Inventory | Landed cost, assemblies/work orders for print-on-demand, valuation snapshots, A07 RFQ |
| 11 Ledger | X01 posting engine, X03 period-lock guard, F04 source-data contract, G08 FX translation, G09 eliminations/NCI, G10 close completeness, G11 disclosures |
| 12 Banking | B01 credit-card statements, B02 cash-flow forecast, B03 settlement reserves, G06 effective-interest debt, R07 undeposited-funds tie-out |
| 13 Receivables | G01 revenue recognition completion, G05 CECL allowance, R01 dunning, R02 credit holds, R03 customer deposits, R04 write-offs, R05 payment-link QR/expiry, R06 surcharge rules |
| 14 Payables | A01 three-way match, A02 vendor refund and credit-card credit, A03 check printing, A04 NACHA and positive pay, A06 payment approval |
| 15 Assets | G02 lease classification/PV, G03 impairment, G04 NRV write-downs, tax book feed for T07 |
| 16 Team | Payroll definition (comp, earning/deduction codes, W-4, garnishments, PTO, wage bases, deposits, 941/940/W-2), Time definition, A05 1099 boxes per payment and TIN matching |
| 17 Sales Tax | Exemption certificates, filing frequencies, economic thresholds, marketplace-facilitator rules for each channel, liability snapshots, returns/payments, product tax codes, S06 |
| 18 Business Tax | F01, F03, F05–F08, T01–T13, P01–P13, S01–S05, D01–D11; fix app_17's date adapter |
| 19 Cap Table | G07 stock-comp expense; merge the two cap models |
| 21 Marketing | M02 newsletter campaigns, M03 one promotion engine |
| 22 Advertising | M01 ad spend → GL |
| 26 Reports | Q01 report definitions and schedules, Q02 dashboard widgets and KPI targets, Q03 materialized views for GMV/orders/support |
| 27 Integrations | Single inbox/outbox/idempotency/jobs |
| 99 | Delete the `pawzly`/`telemed`/`lms` functions; strip `'lms'` from 37 `search_path`s |

---

## 6. Release sequence

| Release | Contents | Gate |
|---|---|---|
| R0 Clean baseline | Remove the 99-domain functions, fix `'lms'` search paths, leave extension functions out of the export | `verify_tree.sh` IDENTICAL against staging |
| R1 September release | Finance 1–9, App 10–15, `unsaid_consolidated` in file order, after reviewing the 7 replaced production functions | All 16 OK (already shown in `tests/deploy_test_results.tsv`); RLS regression test with two tenants |
| R2 Nov 9 tax files | app_16, app_18, and app_17 with `posting_date` hard-coded | All three apply on top of R1 |
| R3 Consolidation | Section 4 clusters, one domain per migration, legacy-write block trigger | No writes to legacy tables in 7 days of logs |
| R4 Cap table and 409A | App Part 19 (`migrations/20261109190000_app_19_cap_table_409a.sql`) on top of R1; retire `409a-cap-table-schema.sql` | `tests/test_app19_cap_409a.sql` prints ALL APP 19 TESTS PASSED |
| R5+ Gap closure | Section 5 by domain: posting engine (11) first, then 14/13/17/09, then 16, then 18, then GAAP/provision | Each domain's gap IDs marked done in the manifest |

After each release, re-export, re-split, verify, and commit the new `schema/` tree.
